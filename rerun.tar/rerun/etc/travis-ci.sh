# Continuous Integration at https://travis-ci.org/rerun/rerun
autoreconf --install
./configure
make check
