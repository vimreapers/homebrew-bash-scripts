If specified `true`, the command will overwrite existing content.
