Specifies the rerun module on which to operate.
