If unspecified, the option name is used as the long name.
