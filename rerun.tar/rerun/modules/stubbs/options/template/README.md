Specifies a module to use as a template when creating a new one.
Can be the name of the module or a path to it.
