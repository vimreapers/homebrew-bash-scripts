Path where output should be written.
