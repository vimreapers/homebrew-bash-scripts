Specify if the option is required. Specify `true` if so.
Commands that require an option will fail if that option is not specified.
