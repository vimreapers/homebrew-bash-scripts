If the option takes argument specify `true` otherwise, it defaults to `false`.
