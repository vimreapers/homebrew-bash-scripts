Specify the command name for the module.
