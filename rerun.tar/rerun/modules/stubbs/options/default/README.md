Give an option a default value.
