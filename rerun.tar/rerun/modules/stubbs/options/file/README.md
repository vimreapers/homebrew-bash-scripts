The path for the output to be written.
