This directory contains platform tests implemented
as vagrant configurations.

Usage
-----

    cd {platform-dir}
    vagrant up


TODO
----

* Write a driver script that brings these boxes up to drive the testing.
