Put common platform tests here.
